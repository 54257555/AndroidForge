# 绿框相机 Android 项目

这是一个原生 Android Studio 项目骨架：CameraX 实时预览 + ML Kit 实时目标检测 + 绿色检测框。

## 构建 APK
1. 在电脑安装 Android Studio（建议当前稳定版）和 Android SDK Platform 35。
2. 解压项目并用 Android Studio 打开 `GreenBoxCamera` 文件夹。
3. 等待 Gradle 同步完成（需要网络下载 Android Gradle Plugin 和依赖）。
4. 连接 Android 手机并允许 USB 调试，或选择 Build > Build Bundle(s) / APK(s) > Build APK(s)。
5. APK 通常生成在 `app/build/outputs/apk/debug/app-debug.apk`。

## 重要限制
- 本项目使用 ML Kit 的通用目标检测器，标签和分类能力有限，不保证能准确区分所有人类、动物或动物物种。
- 绿色框显示的是模型检测到的对象，不是游戏内透视或外挂功能。
- 需在真机上测试不同设备的相机方向、裁剪比例和性能；当前叠框缩放为通用近似实现。
- 此运行环境未执行 Android Gradle 构建，因此这里不包含经过编译/签名/真机验证的 APK。
