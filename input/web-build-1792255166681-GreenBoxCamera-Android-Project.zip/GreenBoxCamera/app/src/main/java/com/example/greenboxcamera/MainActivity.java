package com.example.greenboxcamera;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Bundle;
import android.util.Size;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;

import com.google.common.util.concurrent.ListenableFuture;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.objects.DetectedObject;
import com.google.mlkit.vision.objects.ObjectDetection;
import com.google.mlkit.vision.objects.ObjectDetector;
import com.google.mlkit.vision.objects.defaults.ObjectDetectorOptions;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    private PreviewView previewView;
    private BoxOverlay overlay;
    private TextView status;
    private ExecutorService analysisExecutor;
    private ObjectDetector detector;
    private boolean processing = false;

    private final ActivityResultLauncher<String> cameraPermission =
        registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
            if (granted) startCamera();
            else Toast.makeText(this, "需要相机权限才能进行实时识别", Toast.LENGTH_LONG).show();
        });

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        analysisExecutor = Executors.newSingleThreadExecutor();

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(9, 13, 11));

        previewView = new PreviewView(this);
        previewView.setScaleType(PreviewView.ScaleType.FILL_CENTER);
        root.addView(previewView, new FrameLayout.LayoutParams(-1, -1));

        overlay = new BoxOverlay();
        root.addView(overlay, new FrameLayout.LayoutParams(-1, -1));

        TextView header = new TextView(this);
        header.setText("●  绿框相机     LIVE");
        header.setTextColor(Color.rgb(57, 255, 118));
        header.setTextSize(15);
        header.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        header.setPadding(22, 18, 22, 18);
        header.setBackgroundColor(0xB8090D0B);
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(-1, -2, Gravity.TOP);
        root.addView(header, hp);

        status = new TextView(this);
        status.setText("正在初始化目标识别…");
        status.setTextColor(Color.WHITE);
        status.setTextSize(13);
        status.setPadding(18, 12, 18, 12);
        status.setBackgroundColor(0xB8090D0B);
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        root.addView(status, sp);
        setContentView(root);

        ObjectDetectorOptions options = new ObjectDetectorOptions.Builder()
            .setDetectorMode(ObjectDetectorOptions.STREAM_MODE)
            .enableClassification()
            .build();
        detector = ObjectDetection.getClient(options);

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED) startCamera();
        else cameraPermission.launch(Manifest.permission.CAMERA);
    }

    private void startCamera() {
        ListenableFuture<ProcessCameraProvider> future = ProcessCameraProvider.getInstance(this);
        future.addListener(() -> {
            try {
                ProcessCameraProvider provider = future.get();
                Preview preview = new Preview.Builder().build();
                preview.setSurfaceProvider(previewView.getSurfaceProvider());

                ImageAnalysis analysis = new ImageAnalysis.Builder()
                    .setTargetResolution(new Size(640, 480))
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build();

                analysis.setAnalyzer(analysisExecutor, imageProxy -> {
                    if (processing || imageProxy.getImage() == null) {
                        imageProxy.close();
                        return;
                    }
                    processing = true;
                    InputImage image = InputImage.fromMediaImage(
                        imageProxy.getImage(), imageProxy.getImageInfo().getRotationDegrees());

                    detector.process(image)
                        .addOnSuccessListener(objects -> runOnUiThread(() -> renderObjects(objects, imageProxy.getWidth(), imageProxy.getHeight())))
                        .addOnFailureListener(e -> runOnUiThread(() -> status.setText("识别失败，请重启应用")))
                        .addOnCompleteListener(task -> {
                            processing = false;
                            imageProxy.close();
                        });
                });

                provider.unbindAll();
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis);
                status.setText("实时识别已启动 · 绿色框为检测到的目标");
            } catch (Exception e) {
                status.setText("相机启动失败：" + e.getMessage());
            }
        }, ContextCompat.getMainExecutor(this));
    }

    private void renderObjects(List<DetectedObject> objects, int imageWidth, int imageHeight) {
        List<BoxOverlay.BoxItem> items = new ArrayList<>();
        int count = 0;
        for (DetectedObject obj : objects) {
            String label = "目标";
            float confidence = -1f;
            if (obj.getLabels() != null && !obj.getLabels().isEmpty()) {
                com.google.mlkit.vision.objects.DetectedObject.Label best = obj.getLabels().get(0);
                label = best.getText();
                confidence = best.getConfidence();
            }
            // Default ML Kit model labels broad object categories; do not claim species-level accuracy.
            items.add(new BoxOverlay.BoxItem(obj.getBoundingBox(), label, confidence));
            count++;
        }
        overlay.setItems(items, imageWidth, imageHeight);
        status.setText("检测目标：" + count + "   ·   本地处理");
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        if (detector != null) detector.close();
        if (analysisExecutor != null) analysisExecutor.shutdown();
    }

    static class BoxOverlay extends View {
        static class BoxItem {
            final Rect rect; final String label; final float confidence;
            BoxItem(Rect r, String l, float c) { rect = r; label = l; confidence = c; }
        }
        private final Paint boxPaint = new Paint(3);
        private final Paint textPaint = new Paint(3);
        private final Paint bgPaint = new Paint(3);
        private List<BoxItem> items = new ArrayList<>();
        private int sourceWidth = 640, sourceHeight = 480;

        BoxOverlay() {
            super(null);
            boxPaint.setColor(Color.rgb(57, 255, 118));
            boxPaint.setStyle(Paint.Style.STROKE);
            boxPaint.setStrokeWidth(4f);
            textPaint.setColor(Color.rgb(57, 255, 118));
            textPaint.setTextSize(34f);
            textPaint.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
            bgPaint.setColor(0xC0090D0B);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        }

        void setItems(List<BoxItem> data, int w, int h) {
            items = data;
            sourceWidth = Math.max(1, w);
            sourceHeight = Math.max(1, h);
            invalidate();
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            // Camera preview uses FILL_CENTER; approximate matching for common portrait layouts.
            float scale = Math.max(getWidth() / (float) sourceWidth, getHeight() / (float) sourceHeight);
            float dx = (getWidth() - sourceWidth * scale) / 2f;
            float dy = (getHeight() - sourceHeight * scale) / 2f;
            for (BoxItem item : items) {
                Rect r = item.rect;
                float left = r.left * scale + dx, top = r.top * scale + dy;
                float right = r.right * scale + dx, bottom = r.bottom * scale + dy;
                canvas.drawRect(left, top, right, bottom, boxPaint);
                String conf = item.confidence >= 0 ? String.format(java.util.Locale.US, " %.0f%%", item.confidence * 100) : "";
                String label = item.label + conf;
                float tw = textPaint.measureText(label);
                float labelTop = Math.max(8, top - 44);
                canvas.drawRect(left, labelTop, left + tw + 20, labelTop + 42, bgPaint);
                canvas.drawText(label, left + 10, labelTop + 32, textPaint);
            }
        }
    }
}
